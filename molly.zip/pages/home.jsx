import React from "react";

const HomePage = () => {
  return (
    <div>
      <h3>This will be the homepage</h3>
    </div>
  );
};

export default HomePage;
