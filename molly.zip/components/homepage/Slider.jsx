import React from "react";

const Slider = () => {
  return (
    <div>
      <h3>Slider box</h3>
    </div>
  );
};

export default Slider;
