import React from "react";

const IconCard = () => {
  return (
    <div>
      <h3>card</h3>
    </div>
  );
};

export default IconCard;
