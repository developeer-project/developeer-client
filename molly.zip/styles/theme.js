// /// create a new style sheet

// const myGlobalMantineTheme = {
//     {
//         color
//     },
//     {}
// }
